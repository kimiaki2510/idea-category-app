FactoryBot.define do
  factory :idea do
    body { "MyText" }
    category { nil }
  end
end
