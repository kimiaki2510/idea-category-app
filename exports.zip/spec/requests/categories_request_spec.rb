require 'rails_helper'

RSpec.describe "Categories", type: :request do

end
